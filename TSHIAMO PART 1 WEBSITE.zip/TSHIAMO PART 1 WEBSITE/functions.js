// Charles Retail Therapy – site scripts

// Mobile navigation (hamburger menu)
const navToggle = document.querySelector('.nav-toggle');
const mainNav = document.querySelector('#main-nav');

function setMenuOpen(isOpen) {
    navToggle.setAttribute('aria-expanded', String(isOpen));
    navToggle.querySelector('.sr-only').textContent = isOpen ? 'Close menu' : 'Open menu';
    mainNav.classList.toggle('is-open', isOpen);
}

if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
        setMenuOpen(navToggle.getAttribute('aria-expanded') !== 'true');
    });

    // Close the menu with the Escape key and return focus to the button
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && mainNav.classList.contains('is-open')) {
            setMenuOpen(false);
            navToggle.focus();
        }
    });
}
